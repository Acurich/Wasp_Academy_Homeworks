﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
    // Задача B2.
    // Кол-во стингеров: 🔹
    //
    // Написать функцию OrderWeight(List<int> list), которая сортирует список положительных чисел.
    // Критерий сортировки - возрастание веса числа (сумма всех цифр числа).
    // Если два числа имеют одинаковый вес, сортировать их так, словно они строки.
    //
    // Пример:
    // [56, 65, 74, 100, 99, 68, 86, 180, 90] ==>
    // [100, 180, 90, 56, 65, 74, 68, 86, 99]
    public static class TaskB2
    {
        public static List<int> OrderWeight(List<int> l)
        {

            bool fl = true;
            int buf;
            int sumer1 = 0, sumer2 = 0;
            while (fl)
            {
                fl = false;
                for (int i = 0; i < l.Count - 1; i++)
                {
                    buf = l[i];
                    while (buf.ToString().Length > 1)
                    {
                        sumer1 += buf % 10;
                        buf /= 10;
                    }
                    sumer1 += buf;
                    buf = l[i + 1];
                    while (buf.ToString().Length > 1)
                    {
                        sumer2 += buf % 10;
                        buf /= 10;
                    }
                    sumer2 += buf;
                    if (sumer1 > sumer2)
                    {
                        buf = l[i];
                        l[i] = l[i + 1];
                        l[i + 1] = buf;
                        fl = true;
                    }
                    if (sumer1 == sumer2 && String.Compare(l[i].ToString(), l[i + 1].ToString()) > 0)
                    {
                        buf = l[i];
                        l[i] = l[i + 1];
                        l[i + 1] = buf;
                        fl = true;
                    }
                    sumer1 = 0;
                    sumer2 = 0;
                }
            }
            return l;
        }
    }
}
