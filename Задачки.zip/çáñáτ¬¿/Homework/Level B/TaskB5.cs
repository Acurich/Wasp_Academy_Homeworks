﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
    // Задача B5.
    // Кол-во стингеров: ½🔷
    //
    // Написать функцию Frame(string text, char symbol), которая заключает
    // список строк text в рамку из символов char и возвращает данную строку.
    //
    // Пример:
    // frame(['Create', 'a', 'frame'], '+') ==>
    // ++++++++++
    // + Create +
    // + a      +
    // + frame  +
    // ++++++++++
    public static class TaskB5
    {
        public static string Frame(List<string> t, char symb)
        {
            t = t.ConvertAll(x => " " + x + " ");
            int he = t.Count + 2;
            int w = t.Max(x => x.Length) + 2;
            string ans = "";
            for (int y = 0; y < he; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    if (x == 0 || x == w - 1 || y == 0 || y == he - 1) ans += symb;
                    else
                    {
                        if (x - 1 < t[y - 1].Length) ans += t[y - 1][x - 1];
                        else ans += ' ';
                    }
                }
                ans += '\n';
            }
            return ans.Trim('\n');
        }
    }
}
