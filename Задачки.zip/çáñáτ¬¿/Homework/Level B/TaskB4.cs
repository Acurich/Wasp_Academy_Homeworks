﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
    // Задача B4.
    // Кол-во стингеров: 🔷
    //
    // Написать функцию CheckBrackets(string s), которая определяет,
    // правильно ли расставлены скобки () {} [] <> в предложении.
    //
    // Примеры:
    // CheckBrackets("(abc)[]{0:1}") ==> true;
    // CheckBrackets("(abc)]{0:1}[") ==> false.
    public static class TaskB4
    {
        public static bool CheckBrackets(string sys)
        {
            int checker1 = 0, checker2 = 0, checker3 = 0;
            foreach(char i in sys)
            {
                if (String.Equals(i, "("))
                    checker1++;
                if (String.Equals(i, ")"))
                    checker1--;
                if (String.Equals(i, "{"))
                    checker2++;
                if (String.Equals(i, "}"))
                    checker2--;
                if (String.Equals(i, "<"))
                    checker3++;
                if (String.Equals(i, ">"))
                    checker3--;
            }
            return (checker1 == 0 && checker2 == 0 && checker3 == 0);
        }
    }
}
